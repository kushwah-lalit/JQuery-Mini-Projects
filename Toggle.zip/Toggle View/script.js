var check=false
$("#slider").click(function(){
    if(check==false){
        $("#slider").css({ marginLeft : "50px" });
        $("#bdyy").css({ backgroundColor : "black" });
        $("#txt").css({ color : "white" });
        check=true;
    }else{
        $("#slider").css({ marginLeft : "0px" });
        $("#bdyy").css({ backgroundColor : "white" });
        $("#txt").css({ color : "black" });
        check=false;
    }
});
    