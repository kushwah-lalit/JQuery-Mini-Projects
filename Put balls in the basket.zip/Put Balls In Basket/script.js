var colors = ['red', 'blue', 'yellow', 'lightgrey', 'darkorchid', 'black', 'orange', 'deeppink', 'green', 'purple', 'saddlebrown', 'lightseagreen', 'deepskyblue', 'firebrick', 'crimson'];
$('#btn').click(function(){
    $('#basket').append('<div style="background-color: ' + colors[Math.floor(Math.random()*15)] + '" ></div>');
});