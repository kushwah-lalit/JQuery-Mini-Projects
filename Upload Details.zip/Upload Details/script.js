$("#btn").click(function(event){
    event.preventDefault();
     var num = $("#roll").val();
     var name = $("#name").val();
     var mark = $("#marks").val();
    if(num===""||name===""||mark===""){
        alert("Please fill all the fields");
    }else{
        $("#roll").val("");
        $("#name").val("");
        $("#marks").val("");
        $('#list').append('<div class="items">Roll no - <span class="highlight">' + num + '</span> , <span class="highlight">' + name + '</span> have got <span class="highlight">' + mark + '</span> marks</div>');
    }

});